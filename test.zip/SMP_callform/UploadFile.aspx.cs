using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class UploadFile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string strPath;
        //if (Request.ContentType.IndexOf("multipart/form-data") < 0)
        //    return;

        for (int i = 0; i < Request.Files.Count; i++)
        {
            strPath = "C:\\Apps\\test" + i + ".jpg";
            //dateFileName = DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString() + DateTime.Now.Year.ToString()
            //+ DateTime.Now.Hour.ToString() + DateTime.Now.Date.Minute.ToString() + DateTime.Now.Date.Second.ToString()
            //+ DateTime.Now.Millisecond.ToString() + i;

            HttpPostedFile objFile = Request.Files[i];
            //String strPath = strUploadPath + "\\" + WebAppClass.LoggedUserId + "_" + dateFileName + Path.GetExtension(objFile.FileName);
            //fileNames = WebAppClass.LoggedUserId + "_" + dateFileName + Path.GetExtension(objFile.FileName) + "|" + Path.GetFileName(objFile.FileName) + ";" + objFile.ContentLength / 1024 + '^' + fileNames;
            objFile.SaveAs(strPath);
            // dateFileName = "";
        }
    }
}
