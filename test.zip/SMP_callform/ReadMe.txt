﻿Ver:502 Build:42820091151
====================================
Dont modify the following Files
sparsupport.aspx
global.asax
apputil.config
appcode\AppMaster.cs
appcode\ErrHandler.cs
====================================
Dont Delete the following folders including files and subfolders inside
App_Code
App_themes
Images
Bin
====================================
Dont Delete the following files
web.config
sparsupport.aspx
sparsupport.aspx.cs
global.asax
masterpage.master
apputil.config
appcode\AppMaster.cs
appcode\ErrHandler.cs
====================================

