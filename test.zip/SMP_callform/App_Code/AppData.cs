﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web;



/// <summary>
/// Summary description for AppData
/// </summary>
public class AppData
{
         
    //*************** Procedure CFJWTInputs.aspx
    public static DataTable Get_MerchInfo(Int32 iMerchNo, SqlConnection sqlgetconnection)
        {
                try
                {
                    DataTable appDT = new DataTable();
                    appDT = DAL.usp_CallForm_Merch_Info(iMerchNo, sqlgetconnection);
                    return appDT;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    sqlgetconnection.Close();            
                }
        }
        //*************** Procedure CFJWTInputs.aspx
    public static DataTable Get_CellPhoneCarrier(SqlConnection sqlgetconnection)
        {
            try
            {
                DataTable appDT5 = new DataTable();
                appDT5 = DAL.USP_CFJWT_CellPhoneCarrier(sqlgetconnection);
                return appDT5;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlgetconnection.Close();
            }
        }
   //*************** Procedure CFJWTValidateSV.aspx
    public static DataTable Get_CFJWTValidate(Int32 Lang_id, Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Chain_No, Int32 Store_No, String PVisit_Date, Int32 Merch_no, Int32 POutOfStock_no, SqlConnection sqlgetconnection)
        {
            try
            {
                DataTable appDT = new DataTable();
                appDT = DAL.USP_CFJWTValidate_temp(Lang_id,Job_No, Wave_No, Task_No, Chain_No, Store_No, PVisit_Date, Merch_no, POutOfStock_no, sqlgetconnection);
                return appDT;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlgetconnection.Close();
            }
        }


    public static DataTable Get_MerchJWTMenu(Int32 Lang_id,Int32 iMerchNo,  SqlConnection sqlgetconnection)
        {
                try
                {
                    DataTable appDT = new DataTable();
                    appDT = DAL.usp_MerchJWTMenu(Lang_id,iMerchNo, sqlgetconnection);
                    return appDT;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    sqlgetconnection.Close();            
                }
        }
    public static DataTable Get_ManagerTitle(SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT2 = new DataTable();
            appDT2 = DAL.USP_CFStore_Manager_Title(sqlgetconnection);
            return appDT2;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }
    public static DataTable Get_Start_timeClass(SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT10 = new DataTable();
            appDT10 = DAL.USP_Start_time(sqlgetconnection);
            return appDT10;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }

    public static DataTable Get_JWT_VisitDate_CheckClass(Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Store_id, String Visit_Date, Int32 Merch_no, SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT10 = new DataTable();
            appDT10 = DAL.JWT_VisitDate_CheckProcedure(Job_No, Wave_No, Task_No, Store_id, Visit_Date, Merch_no, sqlgetconnection);
            return appDT10;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }

    
    public static DataTable Get_CFMerchCellPhoneInsert(Int32 Merch_no, String Email_Add, String CellPhoneNo, Int32 CellProvider, Int32 Hidden_PhoneStatus, SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT3 = new DataTable();
            appDT3 = DAL.CFMerchCellPhoneInsertProcedure(Merch_no, Email_Add, CellPhoneNo, CellProvider, Hidden_PhoneStatus, sqlgetconnection);
            return appDT3;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }
      public static DataTable Get_ClassBusinessRulePhoto(Int32 Lang_id, Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 store_id, Int32 Merch_no, SqlConnection sqlgetconnection)
        {
            try
            {
                DataTable appDT14 = new DataTable();
                appDT14 = DAL.USP_CFJWT_Business_RulePhoto(Lang_id, Job_No, Wave_No, Task_No, store_id, Merch_no, sqlgetconnection);
                return appDT14;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlgetconnection.Close();
            }
        }
     
    //*************** CFPictureGetFileOption.aspx

    public static DataTable Get_CFJWTVisit_PhotoDates(Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Chain_No, Int32 Store_No, Int32 merch_no, SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT11 = new DataTable();
            appDT11 = DAL.Get_CFJWTVisit_PhotoProcedure(Job_No, Wave_No, Task_No, Chain_No, Store_No, merch_no, sqlgetconnection);
            return appDT11;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }


    //*************** Procedure CFPictureFileConfirmation.aspx
    public static DataTable Get_CFPictureFileConfirmationinsert(Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Chain_No, Int32 Store_No, Int32 merch_no, Int32 Lang_Id, String Picture_Name, String Visit_Date, String Comments, String PhotoFileName, String PhotoFilePath, Int32 confirmation_no, Int32 mWidth, Int32 mHeight, SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT3 = new DataTable();
            appDT3 = DAL.CFPictureFileConfirmationinsert(Job_No, Wave_No, Task_No, Chain_No, Store_No, merch_no, Lang_Id, Picture_Name, Visit_Date, Comments, PhotoFileName, PhotoFilePath, confirmation_no,mWidth,mHeight,sqlgetconnection);
            return appDT3;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }
   
    public static DataTable Get_CFPhotoSentEmail(Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Chain_No, Int32 Store_No, Int32 merch_no, SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT4 = new DataTable();
            appDT4 = DAL.Get_CFPhotoSentEmailProcedure(Job_No, Wave_No, Task_No, Chain_No, Store_No, merch_no, sqlgetconnection);
            return appDT4;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }
    //****************** CFCallFormInputs 
    public static DataTable Get_USP_JWT_Call_Form(Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Store_id, String Prod_Specific, Int32 Work_Type_Id, String SS_Callform, String Prod_UPC, SqlConnection sqlgetconnection)
                                                                                                                  
    {
        try
        {
            DataTable appDT4 = new DataTable();
            appDT4 = DAL.Get_USP_JWT_Call_FormProcedure(Job_No, Wave_No, Task_No, Store_id, Prod_Specific, Work_Type_Id, SS_Callform, Prod_UPC, sqlgetconnection);
            return appDT4;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }
    public static DataTable Get_USP_Call_Form_RTS_Issues(Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Store_id, SqlConnection sqlgetconnection)
                                                                                                                  
    {
        try
        {
            DataTable appDT4 = new DataTable();
            appDT4 = DAL.Get_USP_Call_Form_RTS_IssuesProcedure(Job_No, Wave_No, Task_No, Store_id, sqlgetconnection);
            return appDT4;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }

    //**************** CFCallFormValidate.aspx
    //*************** Procedure CFJWTValidateSV.aspx
    public static DataTable Get_JWT_CallForm_TempDataClass(Int32 Lang_id, Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Store_id, Int32 Merch_no, String Strdata1, String Strdata2, String Strdata3, String Strdata4, String Strdata5, String Strdata6, String Strdata7, String Strdata8, SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT = new DataTable();
            appDT = DAL.USP_JWT_CallForm_TempData(Lang_id, Job_No, Wave_No, Task_No, Store_id, Merch_no, Strdata1, Strdata2, Strdata3, Strdata4, Strdata5, Strdata6, Strdata7, Strdata8, sqlgetconnection);
            return appDT;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }
   

     public static DataTable Get_CallFormTempDataInsertProcedure(Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Store_id,Int32 Merch_no, String Q_No, String Ans_type, String QuestionResponse, SqlConnection sqlgetconnection)
                                                                                                                  
    {
        try
        {
            DataTable appDT4 = new DataTable();
            appDT4 = DAL.Get_USP_CallForm_TempDataInsert(Job_No, Wave_No, Task_No, Store_id, Merch_no, Q_No, Ans_type, QuestionResponse, sqlgetconnection);
            return appDT4;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }
    public static DataTable Get_CallFormDataDeleteTemp(Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Store_id, Int32 Merch_no, SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT6 = new DataTable();
            appDT6 = DAL.USP_CallForm_DataDelete_Temp(Job_No, Wave_No, Task_No, Store_id, Merch_no, sqlgetconnection);
            return appDT6;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }

    public static DataTable Get_Call_Form_ConfirmationProcedure(Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Store_id, Int32 Merch_no, Int32 visit_no, String Visit_Date, String Time_IN_date, String Time_Out_date, String Visit_time, String HH_Status_Flag, Int32 rad_q_HH_Used, String txt_mileage, String txt_drive, String Data_Col_Method, String overwritetime, Int32 Work_Type_Id, String SS_Callform, String IVR_Start_Time, String Manager_Title, String Manager_name, Int32 Call_Form_Type_No, String StrArray, String user_id, String CUserId, String CIPAddr, SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT7 = new DataTable();
            appDT7 = DAL.USP_Call_Form_Confirmation_Procedure(Job_No, Wave_No, Task_No, Store_id, Merch_no, visit_no, Visit_Date, Time_IN_date, Time_Out_date, Visit_time, HH_Status_Flag, rad_q_HH_Used, txt_mileage, txt_drive, Data_Col_Method, overwritetime, Work_Type_Id, SS_Callform, IVR_Start_Time, Manager_Title, Manager_name, Call_Form_Type_No, StrArray, user_id, CUserId, CIPAddr, sqlgetconnection);
            return appDT7;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }
    public static DataTable Get_DropDownProductList(Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Store_id, SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT8 = new DataTable();
            appDT8 = DAL.USP_Get_UPC_List_New_Procedure(Job_No, Wave_No, Task_No, Store_id, sqlgetconnection);
            return appDT8;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }
    public static DataTable Get_JWT_QuestionsData(Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Store_id, SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT9 = new DataTable();
            appDT9 = DAL.usp_Get_UPC_Questions_Proceudre(Job_No, Wave_No, Task_No, Store_id, sqlgetconnection);
            return appDT9;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }

    public static DataTable Get_JWTQuestionResponseData(Int32 Job_No, Int32 Wave_No, Int32 Task_No,  SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT10 = new DataTable();
            appDT10 = DAL.JWTQuestionResponse_Proceudre(Job_No, Wave_No, Task_No, sqlgetconnection);
            return appDT10;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }
    //*************** Procedure CFJWTValidateSV.aspx
    public static DataTable Get_JWT_Product_TempDataClass(Int32 Lang_id, Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Store_id, Int32 Merch_no,String Strdata1, String Strdata2, String Strdata3, String Strdata4, String Strdata5, String Strdata6, String Strdata7, String Strdata8, SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT = new DataTable();
            appDT = DAL.USP_JWT_Product_TempData(Lang_id, Job_No, Wave_No, Task_No, Store_id, Merch_no, Strdata1, Strdata2, Strdata3, Strdata4, Strdata5, Strdata6, Strdata7, Strdata8, sqlgetconnection);
            return appDT;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }
   
        //*************** Procedure CFJWTValidateSV.aspx
    public static DataTable Get_Grid_Reported_AnswersClass(Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Store_id, Int32 Merch_no, SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT = new DataTable();
            appDT = DAL.Get_Grid_Reported_AnswersProcedure(Job_No, Wave_No, Task_No, Store_id, Merch_no, sqlgetconnection);
            return appDT;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }


    public static DataTable Get_Product_ConfirmationProcedure(Int32 Lang_id, Int32 Job_No, Int32 Wave_No, Int32 Task_No, Int32 Store_id, Int32 Merch_no, Int32 visit_no, String Visit_Date, String Time_IN_date, String Time_Out_date, String Visit_time, String Manager_Title, String Manager_name, String txt_mileage, String txt_drive, String Data_Col_Method, String IVR_Start_Time, String user_id, String CUserId, String CIPAddr, SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT11 = new DataTable();
            appDT11 = DAL.USP_Product_Confirmation_Procedure(Lang_id,Job_No, Wave_No, Task_No, Store_id, Merch_no, visit_no, Visit_Date, Time_IN_date, Time_Out_date, Visit_time,Manager_Title, Manager_name, txt_mileage, txt_drive, Data_Col_Method, IVR_Start_Time, user_id,CUserId, CIPAddr,  sqlgetconnection);
            return appDT11;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }

    public static DataTable Get_JWT_Store_SearchClass(Int32 Job_No, Int32 Wave_No, Int32 Task_No, String Store_name, String Store_add, String Store_city, String Store_state, String Store_zip, SqlConnection sqlgetconnection)
    {
        try
        {
            DataTable appDT12 = new DataTable();
            appDT12 = DAL.USP_JWT_Store_Search_Procedure(Job_No, Wave_No, Task_No, Store_name, Store_add, Store_city, Store_state, Store_zip, sqlgetconnection);
            return appDT12;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlgetconnection.Close();
        }
    }
   

}
