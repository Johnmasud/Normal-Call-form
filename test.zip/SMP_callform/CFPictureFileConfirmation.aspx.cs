using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SPAR.Tools.Security;
using SPAR.Tools.MasterControls;
using SPAR.Tools.Utils;
using System.IO;
using System.Text;
using System.Net.Mail;

public partial class CFPictureFileConfirmation : System.Web.UI.Page
{
    protected string Job_No, Wave_No, Task_No, Task_Desc, Task_Addtl_Desc, store_id, AddressRule, NameRule, DateRule, Date_input, VarDay, Varmonth, StrYear;
    protected string Chain_No, Store_Chain_Desc, Store_No, Store_Store_Name, Store_Street_Addr, Store_City, Store_State, Store_Zip;
    protected string CA_merch_no, Str_Merch_no, Merch_First_Name, Merch_Last_Name, Merch_Street_Addr, Merch_Street_Addr2, Merch_City, Merch_State, Merch_Zip, Merch_Phone_No, Merch_Email_Addr;
    protected string Field_Start_Dt, Field_end_Dt, Key_Comp_Dt, DOA_Dt, TodayDate, visit_no, PagePath, StrOriginalFile;
    protected string Collect_iVR_Time, night_visits, Mileage_flag, Travel_flag, RotateFileSave, Rotate, Str_Manager_Title, Str_txt_Manager_name;
    protected string Job_Type, Business_Type_id, Work_Type_id, Work_Type_Desc, StrImgUrl, StrFileSave, hiddentest, StrRotateFileSave, StrNewFileSave;
    protected string Data_Col_Method, overwritetime, All_Data_Received, collect_time_only, Ask_Q_HH_Used, HH_Status_Flag, FileUploadType;
    protected string Collect_Header, Collect_Call_Form, SS_Callform, Prod_Specific, qdef_skippattern, Max_Mx_Per_Store, Max_Visit_Per_Store_Mx;
    protected string Collect_Store_Mgr_Name, Product_Check_Flag, Ask_EShelf_Question, Call_Form_Type_No, Est_instore_minutes, Business_Rule_Eckerd, Eckerd_Job_Last_question;
    protected string user_id, PhotoButton, Bus_Rule5_Question, Bus_Rule6_Question, Bus_Rule28_Question, Bus_Rule3_Question, Bus_Rule4_Question, Bus_Rule7_Question;
    public string[] vPrompts;
    protected string Str_VisitMonth, Str_visitday, Str_visityear, Str_timein_hrs, Str_timein_min, Str_cmb_timein, Str_timeout_hrs, Str_timeout_min, Str_cmb_timeout, StrNewUploadFile;
    protected string Str_txt_mileage, Str_txt_drive, Str_rad_q_Past_Midnight, Str_rad_q_HH_Used, Str_rad_q_Ret_store_visit, SelectCheckboxFiles, Visit_Dates;
    protected string Str_Radio_EShelf, Str_Ask_EShelf_Question, Str_Bus_Rule3_Question, Str_rad_q_BR3, Str_Bus_Rule4_Question, Str_rad_q_BR4, Str_Bus_Rule5_Question;
    protected string Str_rad_q_BR5, Str_Bus_Rule6_Question, Str_rad_q_BR6, Str_Bus_Rule7_Question, Str_rad_q_BR7, Str_Bus_Rule28_Question, Str_rad_q_BR28, PVisit_Date, Picture_Name, Comments, PhotoFileName, PhotoFilePath, CommentBox;
    protected int Back_Slash, Dot, Dash, ShowType, Lang_id, confirmation_no, Str_Lang_id, mWidth, mHeight;
    protected string PEmail_String, PMerch_Full_Name, PTask_Addtl_Desc, PField_Start_Dt, PField_end_Dt, PTask_Desc, PhotoCounter;
    protected string PStore_Chain_Desc, PStore_Store_Name, PStore_Street_Addr, PStore_City, PStore_State, PStore_Zip;
    protected string PMerch_Phone_No, PMerch_Email_Addr, PClientServ_PersonNo, EmailInfoText, StrFileUpdatePath, StrFileWorkPath, StrFileApprovedPath, StrFilePathdb;  
    public DateTime StrDate;
    private string Str_Request_Method;

    #region SPARUTILS
    //code block for masterpage app, dont remove
    SPARValues WebAppClass;
    PromptTranslation ptAppTranslation;
    
 
    protected void Page_PreInit()
    {
        Str_Request_Method = Request.ServerVariables.Get("REQUEST_METHOD").ToString();
        //Response.Write("Str_Request_Method=" + Str_Request_Method + "<BR>");

        if (Str_Request_Method == "GET")
        {
            Response.Redirect("https://mi12.sparinc.com/MXToolsLogin/MXSparmenu.asp");
        }

        SPARHeader PageHeader;
        SPARFooter PageFooter;
        SPARBiLingualBar BiLingualBar;
        PageHeader = (SPARHeader)this.Master.FindControl("SPARHeader1");
        PageFooter = (SPARFooter)this.Master.FindControl("SPARFooter1");
        BiLingualBar = (SPARBiLingualBar)this.Master.FindControl("SPARBiLingualBar1");
        WebAppClass = new SPARValues();
     
        WebAppClass.PageTitle = "";

        ptAppTranslation = new PromptTranslation("CFPictureFileConfirmation.aspx", WebAppClass.PromptsLanguageId.ToString(), WebAppClass.LanguageId, WebAppClass.CurrentSQLDBConnection, WebAppClass.MultiLanguageCount);
        AppMasterControls ap1 = new AppMasterControls(PageHeader, PageFooter, BiLingualBar, WebAppClass.LoggedUserName, WebAppClass.CurrentDBDateTime, WebAppClass.LanguageId, WebAppClass.PromptsLanguageId, WebAppClass.MultiLanguageCount, WebAppClass.PageTitle, WebAppClass.CurrentSQLDBConnection, this.Page, WebAppClass.SPARLogoFileURL);
        if (WebAppClass.MerchNo > 0)
        {
            PageFooter.ShowSPARToolsURL = false;
            PageFooter.ShowMainPageUrl = false;
        } 
    }
    protected void Page_PreRender(object sender, EventArgs e)
    {
        ptAppTranslation.DoPagePromptTranslation(this.Page);
       
    }

    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
                                WebAppClass.Set_MerchforForm(this.Merch_no, Convert.ToString(WebAppClass.MerchNo));
                                //****** System Rules
                                DataTable RuleTab = new DataTable();
                                RuleTab = GetSystemRules();

                                AddressRule = RuleTab.Rows[5][2].ToString();
                                //Response.Write("AddressRule=" + AddressRule);

                                DateRule = RuleTab.Rows[1][2].ToString();
                               // Response.Write("DateRule=" + DateRule);

                                NameRule = RuleTab.Rows[0][2].ToString();
                                //Response.Write("NameRule=" + NameRule);

                                //****** Prompts
                                GetPromptTranslation();

                            
                                //******************************* Date format

                                Back_Slash = DateRule.IndexOf("/");
                                //response.write "Back_Slash=" & Back_Slash & "<BR>" 
                                if (Back_Slash > 0)
                                {
                                    Date_input = "/";
                                }
                                Dot = DateRule.IndexOf(".");
                                //response.write "Dot=" & Dot & "<BR>" 
                                if (Dot > 0)
                                {
                                    Date_input = ".";
                                }
                                Dash = DateRule.IndexOf("-");
                                //response.write "Dot=" & Dot & "<BR>" 
                                if (Dash > 0)
                                {
                                    Date_input = "-";
                                }
                                //Response.Write("Date_input=" + Date_input + "<BR>");
                                //****** Today's date 

                                //  int TodayMonth = System.DateTime.Now.Month;
                                // Response.Write("TodayDate =" + TodayDate + "<BR>");

                                Lang_id = WebAppClass.LanguageId;
                                //Response.Write(Lang_id);

                               // Str_User_id = WebAppClass.LoggedUserId;
                                //Response.Write("Str_User_id=" + Str_User_id);

                                StrFileUpdatePath = ConfigurationManager.AppSettings["FileUpdatePath"];
                                //Response.Write("StrFileUpdatePath=" + StrFileUpdatePath);
                               

                                StrFileWorkPath = ConfigurationManager.AppSettings["FileWorkPath"];
                                //Response.Write("StrFileWorkPath=" + StrFileWorkPath);
                               
                                StrFileApprovedPath = ConfigurationManager.AppSettings["FileApprovedPath"];
                                //Response.Write("StrFileApprovedPath=" + StrFileApprovedPath);
                               

                                StrFilePathdb = ConfigurationManager.AppSettings["FilePathdb"];
                                //Response.Write("StrFileApprovedPath=" + StrFileApprovedPath);
                               

                                if (Lang_id == 13)
                                {
                                     
                                    StrFileUpdatePath = StrFileUpdatePath + "sparEyesPic13\\\\update\\\\";
                                    StrFileWorkPath = StrFileWorkPath + "sparEyesPic1\\\\working\\\\";
                                    StrFileApprovedPath = StrFileApprovedPath + "sparEyesPic1\\\\approved\\\\";
                                    StrFilePathdb = StrFilePathdb + "sparEyesPic1\\working\\";
                                     StrFileApprovedPath = StrFileApprovedPath + "sparEyesPic" + Convert.ToString(Lang_id) + "\\\\approved\\\\";
                                    Str_Lang_id = 1;
                                }
                                else
                                {
                                    Str_Lang_id=Lang_id;
                                    StrFileUpdatePath = StrFileUpdatePath + "sparEyesPic" + Convert.ToString(Lang_id) + "\\\\update\\\\";
                                    StrFileWorkPath = StrFileWorkPath + "sparEyesPic" + Convert.ToString(Lang_id) + "\\\\working\\\\";
                                    StrFileApprovedPath = StrFileApprovedPath + "sparEyesPic" + Convert.ToString(Lang_id) + "\\\\approved\\\\";
                                    StrFilePathdb = StrFilePathdb + "sparEyesPic" + Convert.ToString(Lang_id) + "\\working\\";
                                }

                                // Response.Write("good job <BR>");
                                Job_No = Request.Form["Job_No"];
                                // Response.Write("Job_No=" + Job_No);
                                Wave_No = Request.Form["Wave_No"];
                                Task_No = Request.Form["Task_No"];
                                Task_Desc = Request.Form["Task_Desc"];
                                Task_Addtl_Desc = Request.Form["Task_Addtl_Desc"];

                                store_id = Request.Form["store_id"];

                                Chain_No = Request.Form["Chain_No"];
                                Store_Chain_Desc = Request.Form["Store_Chain_Desc"];
                                Store_No = Request.Form["Store_No"];
                                Store_Store_Name = Request.Form["Store_Store_Name"];
                                Store_Street_Addr = Request.Form["Store_Street_Addr"];
                                Store_City = Request.Form["Store_City"];
                                Store_State = Request.Form["Store_State"];
                                Store_Zip = Request.Form["Store_Zip"];

                                CA_merch_no = Request.Form["CA_merch_no"];
                                Str_Merch_no = Request.Form["Str_Merch_no"];
                                Merch_First_Name = Request.Form["Merch_First_Name"];
                                Merch_Last_Name = Request.Form["Merch_Last_Name"];
                                Merch_Street_Addr = Request.Form["Merch_Street_Addr"];
                                Merch_Street_Addr2 = Request.Form["Merch_Street_Addr2"];
                                Merch_City = Request.Form["Merch_City"];
                                Merch_State = Request.Form["Merch_State"];
                                Merch_Zip = Request.Form["Merch_Zip"];
                                Merch_Phone_No = Request.Form["Merch_Phone_No"];
                                Merch_Email_Addr = Request.Form["Merch_Email_Addr"];


                                Field_Start_Dt = Request.Form["Field_Start_Dt"];
                                Field_end_Dt = Request.Form["Field_end_Dt"];
                                Key_Comp_Dt = Request.Form["Key_Comp_Dt"];
                                DOA_Dt = Request.Form["DOA_Dt"];

                                TodayDate = Request.Form["TodayDate"];

                                visit_no = Request.Form["visit_no"];

                                Collect_iVR_Time = Request.Form["Collect_iVR_Time"];
                                night_visits = Request.Form["night_visits"];
                                Mileage_flag = Request.Form["Mileage_flag"];
                                Travel_flag = Request.Form["Travel_flag"];

                                Job_Type = Request.Form["Job_Type"];
                                Business_Type_id = Request.Form["Business_Type_id"];

                                Work_Type_id = Request.Form["Work_Type_id"];
                                Work_Type_Desc = Request.Form["Work_Type_Desc"];

                                Data_Col_Method = Request.Form["Data_Col_Method"];
                                overwritetime = Request.Form["overwritetime"];
                                All_Data_Received = Request.Form["All_Data_Received"];
                                collect_time_only = Request.Form["collect_time_only"];
                                Ask_Q_HH_Used = Request.Form["Ask_Q_HH_Used"];
                                HH_Status_Flag = Request.Form["HH_Status_Flag"];

                                Collect_Header = Request.Form["Collect_Header"];
                                Collect_Call_Form = Request.Form["Collect_Call_Form"];

                                SS_Callform = Request.Form["SS_Callform"];
                                Prod_Specific = Request.Form["Prod_Specific"];
                                qdef_skippattern = Request.Form["qdef_skippattern"];

                                Max_Mx_Per_Store = Request.Form["Max_Mx_Per_Store"];
                                Max_Visit_Per_Store_Mx = Request.Form["Max_Visit_Per_Store_Mx"];

                                Collect_Store_Mgr_Name = Request.Form["Collect_Store_Mgr_Name"];

                                Product_Check_Flag = Request.Form["Product_Check_Flag"];

                                Ask_EShelf_Question = Request.Form["Ask_EShelf_Question"];

                                Call_Form_Type_No = Request.Form["Call_Form_Type_No"];

                                Est_instore_minutes = Request.Form["Est_instore_minutes"];
                                Business_Rule_Eckerd = Request.Form["Business_Rule_Eckerd"];
                                Eckerd_Job_Last_question = Request.Form["Eckerd_Job_Last_question"];

                                user_id = Request.Form["user_id"];
                                PhotoButton = Request.Form["PhotoButton"];
                                Bus_Rule5_Question = Request.Form["Bus_Rule5_Question"];
                                Bus_Rule6_Question = Request.Form["Bus_Rule6_Question"];
                                Bus_Rule28_Question = Request.Form["Bus_Rule28_Question"];
                                Bus_Rule3_Question = Request.Form["Bus_Rule3_Question"];
                                Bus_Rule4_Question = Request.Form["Bus_Rule4_Question"];
                                // Response.Write("Bus_Rule4_Question=" + Bus_Rule4_Question);
                                Bus_Rule7_Question = Request.Form["Bus_Rule7_Question"];

                                //************************ From the page CFJWTValidate.asp
                         //***** visit date 
                                Str_VisitMonth = Request.Form["Str_VisitMonth"];
                                // Response.Write("Str_VisitMonth=" + Str_VisitMonth + "<BR>");

                                Str_visitday = Request.Form["Str_visitday"];
                                //Response.Write("Str_visitday=" + Str_visitday + "<BR>");

                                Str_visityear = Request.Form["Str_visityear"];
                                //Response.Write("Str_visityear=" + Str_visityear + "<BR>");

                          //*******Time in and out     
                                Str_timein_hrs = Request.Form["Str_timein_hrs"];
                                // Response.Write("Str_timein_hrs=" + Str_timein_hrs + "<BR>");
                                Str_timein_min = Request.Form["Str_timein_min"];
                                //Response.Write("Str_timein_min=" + Str_timein_min + "<BR>");
                                Str_cmb_timein = Request.Form["Str_cmb_timein"];
                                //Response.Write("Str_cmb_timein=" + Str_cmb_timein + "<BR>");

                                Str_timeout_hrs = Request.Form["Str_timeout_hrs"];
                                //Response.Write("Str_timeout_hrs=" + Str_timeout_hrs + "<BR>");
                                Str_timeout_min = Request.Form["Str_timeout_min"];
                                // Response.Write("Str_timeout_min=" + Str_timeout_min + "<BR>");
                                Str_cmb_timeout = Request.Form["Str_cmb_timeout"];
                                //Response.Write("Str_cmb_timeout=" + Str_cmb_timeout + "<BR>");

                         //******** mileage		

                                Str_txt_mileage = Request.Form["Str_txt_mileage"];
                                //Response.Write("Str_txt_mileage=" + Str_txt_mileage + "<BR>");

                         //******** drive		
                                Str_txt_drive = Request.Form["Str_txt_drive"];
                                // Response.Write("Str_txt_drive=" + Str_txt_drive + "<BR>");

                         //******** Time Question

                                Str_rad_q_Past_Midnight = Request.Form["Str_rad_q_Past_Midnight"];
                                //Response.Write("Str_rad_q_Past_Midnight=" + Str_rad_q_Past_Midnight + "<BR>");

                         //******** Hand Held Question

                                Str_rad_q_HH_Used = Request.Form["Str_rad_q_HH_Used"];
                                //Response.Write("Str_rad_q_HH_Used=" + Str_rad_q_HH_Used + "<BR>");

                         //******** Time Store Visit

                                Str_rad_q_Ret_store_visit = Request.Form["Str_rad_q_Ret_store_visit"];
                                //Response.Write("Str_rad_q_Ret_store_visit=" + Str_rad_q_Ret_store_visit + "<BR>");

                         //******** For EShelf 	

                                Str_Radio_EShelf = Request.Form["Str_Radio_EShelf"];
                                //Response.Write("Str_Radio_EShelf=" + Str_Radio_EShelf + "<BR>");

                                Str_Ask_EShelf_Question = Request.Form["Str_Ask_EShelf_Question"];
                                //Response.Write("Str_Ask_EShelf_Question=" + Str_Ask_EShelf_Question + "<BR>");

                       //******** business rules
                                Str_Bus_Rule3_Question = Request.Form["Str_Bus_Rule3_Question"];
                                //Response.Write("Str_Bus_Rule3_Question=" + Str_Bus_Rule3_Question + "<BR>");

                                Str_rad_q_BR3 = Request.Form["Str_rad_q_BR3"];
                                //Response.Write("Str_rad_q_BR3=" + Str_rad_q_BR3 + "<BR>");

                                Str_Bus_Rule4_Question = Request.Form["Str_Bus_Rule4_Question"];
                                //Response.Write("Str_Bus_Rule4_Question=" + Str_Bus_Rule4_Question + "<BR>");

                                Str_rad_q_BR4 = Request.Form["Str_rad_q_BR4"];
                                //Response.Write("Str_rad_q_BR4=" + Str_rad_q_BR4 + "<BR>");

                                Str_Bus_Rule5_Question = Request.Form["Str_Bus_Rule5_Question"];
                                //Response.Write("Str_Bus_Rule5_Question=" + Str_Bus_Rule5_Question + "<BR>");
                                Str_rad_q_BR5 = Request.Form["Str_rad_q_BR5"];
                                //Response.Write("Str_rad_q_BR5=" + Str_rad_q_BR5 + "<BR>");

                                Str_Bus_Rule6_Question = Request.Form["Str_Bus_Rule6_Question"];
                                //Response.Write("Str_Bus_Rule6_Question=" + Str_Bus_Rule6_Question + "<BR>");
                                Str_rad_q_BR6 = Request.Form["Str_rad_q_BR6"];
                                // Response.Write("Str_rad_q_BR6=" + Str_rad_q_BR6 + "<BR>");

                                Str_Bus_Rule7_Question = Request.Form["Str_Bus_Rule7_Question"];
                                // Response.Write("Str_Bus_Rule7_Question=" + Str_Bus_Rule7_Question + "<BR>");
                                Str_rad_q_BR7 = Request.Form["Str_rad_q_BR7"];
                                //Response.Write("Str_rad_q_BR7=" + Str_rad_q_BR7 + "<BR>");

                                Str_Bus_Rule28_Question = Request.Form["Str_Bus_Rule28_Question"];
                                // Response.Write("Str_Bus_Rule28_Question=" + Str_Bus_Rule28_Question + "<BR>");
                                Str_rad_q_BR28 = Request.Form["Str_rad_q_BR28"];
                                // Response.Write("Str_rad_q_BR28=" + Str_rad_q_BR28 + "<BR>");

                                Str_Manager_Title = Request.Form["Str_Manager_Title"];
                                //Response.Write("Str_Manager_Title=" + Str_Manager_Title + "<BR>");
                                Str_txt_Manager_name = Request.Form["Str_txt_Manager_name"];
                               // Response.Write("Str_txt_Manager_name=" + Str_txt_Manager_name + "<BR>");
                                //Response.Write("Str_rad_q_BR28=" + Str_rad_q_BR28 + "<BR>");


                      //********Rotate file name 
                                //RotateFileSave = Request.Form["RotateFileSave"];
                                StrRotateFileSave = Request.Form["StrRotateFileSave"];
                               // Response.Write("StrRotateFileSave=" + StrRotateFileSave + "<BR>");

                      //********Original file name 
                                StrOriginalFile = Request.Form["StrOriginalFile"];
                               // Response.Write("RotateFileSave=" + RotateFileSave + "<BR>");
                               // Response.Write("StrOriginalFile=" + StrOriginalFile + "<BR>");


                      //******** Selected files from checkbox
                                SelectCheckboxFiles = Request.Form["SelectCheckboxFiles"];
                                // Response.Write("RotateFileSave=" + RotateFileSave + "<BR>");
                                //Response.Write("SelectCheckboxFiles=" + SelectCheckboxFiles + "<BR>");

                      //******* Visit Dates
                                Visit_Dates = Request.Form["Visit_Dates"];
                                // Response.Write("RotateFileSave=" + RotateFileSave + "<BR>");
                               // Response.Write("Visit_Dates=" + Visit_Dates + "<BR>");

                                PhotoCounter = Request.Form["PhotoCounter"];
                                //Response.Write("PhotoCounter=" + PhotoCounter + "<BR>");
                                FileUploadType = Request.Form["FileUploadType"];

                //***********  File Check
                                int StrFileYear, StrFileMonth, StrFileDay, StrFileHour, StrFileMinute, StrFileSecond, StrFileMillisecond;
                     int StrConfDay, Curday, Tempday, TempHours, TempMin,TempSec, x;
                     String StrSec, StrMin, StrHou, StrComments, Email_String, StrConfirHTML, StrMillisec;
                    x=1;
                    PVisit_Date = "";
                    StrNewFileSave = "";
      //*********************** Check for the selected files from checkbox
                    if (SelectCheckboxFiles != "")
                    {
                                    int m;
                                    string[] ArrayCheckboxFiles = SelectCheckboxFiles.Split('|');
                                    string[] ArrayVisitDates = Visit_Dates.Split('|');
                                    string[] ArrayPhotoCount = PhotoCounter.Split('|'); 
                                   //Lang_id
                                    
                                    //Response.Write("test=" + StrOriginalFile);  
                                    int k, A,CBA;

                                    string LoopFile, StrConfirHTMLShow, StrFileApproved,SPC;
                                    StrConfirHTMLShow = "";
                                    A = ArrayCheckboxFiles.Length;
                                    m = 0;
                                    for (k = 0; k < A; k++)
                                    {
                                        LoopFile = ArrayCheckboxFiles[k];
                                        PVisit_Date = ArrayVisitDates[k];
                                        SPC=ArrayPhotoCount[k];
                                        CBA=Convert.ToInt32(SPC);
                                        if (CBA < 10)
                                        {
                                            StrComments = "ctl00$ContentPlaceHolder1$Repeater1$ctl0" + CBA + "$Comments";
                                            CommentBox = Request.Form["" + StrComments + ""].ToString();
   
                                        }
                                        else
                                        {
                                            StrComments = "ctl00$ContentPlaceHolder1$Repeater1$ctl1" + CBA + "$Comments";
                                            CommentBox = Request.Form["" + StrComments + ""].ToString();
                                           
                                        }
                                        
                                        CommentBox = CommentBox.Replace("'", "''");
                                        //Response.Write("CommentBox=" + CommentBox); 

                                        //Response.Write("LoopVisitDates=" + LoopVisitDates + "<BR>");

                                        //StrNewUploadFile = "C:\\Photo\\Update\\" + LoopFile + ".jpg";
                                        StrNewUploadFile = "" + StrFileUpdatePath + "" + LoopFile + ".jpg";
                                       
                                        //Response.Write("StrNewUploadFile=" + StrNewUploadFile + "<BR>");

                                        if (File.Exists(StrNewUploadFile))
                                        {
                                            //Response.Write("File Exists!=" + StrNewUploadFile);

                                            //***************Confirmation Number                    
                                            //getting day                                   
                                            StrConfDay = DateTime.Now.Day;
                                            Curday = StrConfDay + 10;
                                            Tempday = (Curday) * (100000);
                                            //getting hours                    
                                            TempHours = DateTime.Now.Hour;
                                            //getting mins                    
                                            TempMin = DateTime.Now.Minute;
                                            //getting seconds                    
                                            TempSec = DateTime.Now.Second;
                                            TempMin = TempMin * 100;
                                            TempHours = 50 - TempHours;

                                            confirmation_no = Tempday + TempMin + TempHours + TempSec + k;
                                            // Response.Write("confirmation_no=" + confirmation_no + "<BR>");
                                            //************  New File Name'


                                            m = k + 1;
                                            StrConfirHTML = "<span class='reportCriteriaHeader'>" + vPrompts[48] + "" + m + ":</span><span class='selectionCriteriaItem'><B>" + confirmation_no + "</B></span>";
                                            StrConfirHTMLShow = StrConfirHTMLShow + "<br />" + StrConfirHTML;
                                            DisplayConfirNo.InnerHtml = StrConfirHTMLShow;

                                            StrFileYear = System.DateTime.Now.Year;
                                            StrFileMonth = System.DateTime.Now.Month;
                                            StrFileDay = System.DateTime.Now.Day;
                                            StrFileHour = System.DateTime.Now.Hour;
                                            StrFileMinute = System.DateTime.Now.Minute;
                                            StrFileSecond = System.DateTime.Now.Second;
                                            StrFileMillisecond = System.DateTime.Now.Millisecond;

                                            StrSec = Convert.ToString(StrFileSecond);
                                            StrMin = Convert.ToString(StrFileMinute);
                                            StrHou = Convert.ToString(StrFileHour);
                                            StrMillisec = Convert.ToString(StrFileMillisecond);

                                            if (Convert.ToString(StrFileSecond).Length == 1)
                                            {
                                                StrSec = "0" + StrSec + "";
                                            }
                                            if (Convert.ToString(StrFileMinute).Length == 1)
                                            {
                                                StrMin = "0" + StrMin + "";
                                            }
                                            if (Convert.ToString(StrFileHour).Length == 1)
                                            {
                                                StrHou = "0" + StrHou + "";
                                            }


                                            Picture_Name = "" + Job_No.Trim() + "" + Wave_No.Trim() + "" + Task_No.Trim() + "" + store_id.Trim() + "" + Str_Merch_no.Trim() + "_" + StrFileYear + "" + StrFileMonth + "" + StrFileDay + "" + StrHou.Trim() + "" + StrMin.Trim() + "" + StrSec.Trim() + "" + StrMillisec.Trim() + "" + k + ""; 
                                            // Response.Write("Picture_Name=" + Picture_Name + "<BR>");
                                            PhotoFileName = Picture_Name.Trim() + ".jpg";
                                            //StrNewFileSave = "C:\\Photo\\Working\\" + Picture_Name + ".jpg";
                                            StrNewFileSave = "" + StrFileWorkPath.Trim() + "" + Picture_Name.Trim() + ".jpg";
                                             Response.Write("StrNewFileSave=" + StrNewFileSave + "<BR>");
                                            PhotoFilePath = "" + StrFilePathdb.Trim() + "" + Picture_Name.Trim() + ".jpg";
                                            //******** Photo Width and height

                                            System.Drawing.Image mImg = System.Drawing.Image.FromFile(StrNewUploadFile);
                                             mWidth = mImg.Width;
                                             mHeight = mImg.Height;
                                            //Response.Write("mWidth=" + mWidth + "<BR>");
                                            //Response.Write("mHeight=" + mHeight + "<BR>");
                                            mImg.Dispose();

                                            //******** Copy the File to Working folder
                                            File.Copy(StrNewUploadFile, StrNewFileSave);

                                            if (Lang_id == 7)
                                            {
                                                //StrFileApproved="C:\\Photo\\approved\\" + Picture_Name + ".jpg";
                                                StrFileApproved = "" + StrFileApprovedPath.Trim() + "" + Picture_Name.Trim() + ".jpg";
                                                //PhotoFilePath = PhotoFilePath;
                                                File.Copy(StrNewFileSave, StrFileApproved);
                                                File.Delete(StrNewFileSave);
                                                //objFSO.DeleteFile("" & FilePath & "\working\" & Picture_Name & ".jpg")
                                            }//if (Lang_id == 7)

                                            //**************** Validation procedure
                                            Get_PhotoInsert(Job_No, Wave_No, Task_No, Chain_No, Store_No, Str_Merch_no, Str_Lang_id, Picture_Name, PVisit_Date, CommentBox, PhotoFileName, PhotoFilePath, confirmation_no, mWidth, mHeight);

                                        }
                                        else
                                        {
                                            Label1.Visible = false;     
                                            DisplayConfirNo.InnerHtml = "<span class='reportCriteriaHeader'>" + vPrompts[35] + " </span>";
                                        }
                                        //**************** Check the file to see if exist in working folder
                                        if (File.Exists(StrNewFileSave))
                                        {
                                             DataTable dt1 = Get_PhotoSentEmail(Job_No, Wave_No, Task_No, Chain_No, Store_No, Str_Merch_no);
                                                PEmail_String = dt1.Rows[0][0].ToString();
                                                //Response.Write("PEmail_String=" + PEmail_String + "<BR>");
                                                PMerch_Full_Name = dt1.Rows[0]["Merch_Full_Name"].ToString();
                                                //Response.Write("PMerch_Full_Name=" + PMerch_Full_Name + "<BR>");
                                                PTask_Addtl_Desc = dt1.Rows[0]["Task_Addtl_Desc"].ToString();
                                                PField_Start_Dt = dt1.Rows[0]["Field_Start_Dt"].ToString();
                                                PField_end_Dt = dt1.Rows[0]["Field_end_Dt"].ToString();
                                                PTask_Desc = dt1.Rows[0]["Task_Desc"].ToString();
                                                PStore_Chain_Desc = dt1.Rows[0]["Store_Chain_Desc"].ToString();
                                                PStore_Store_Name = dt1.Rows[0]["Store_Store_Name"].ToString();
                                                PStore_Street_Addr = dt1.Rows[0]["Store_Street_Addr"].ToString();
                                                PStore_City = dt1.Rows[0]["Store_City"].ToString();
                                                PStore_State = dt1.Rows[0]["Store_State"].ToString();
                                                PStore_Zip = dt1.Rows[0]["Store_Zip"].ToString();
                                                PMerch_Phone_No = dt1.Rows[0]["Merch_Phone_No"].ToString();
                                                PMerch_Email_Addr = dt1.Rows[0]["Merch_Email_Addr"].ToString();
                                                PClientServ_PersonNo = dt1.Rows[0]["ClientServ_PersonNo"].ToString();
                                               // Response.Write("PMerch_Full_Name=" + PMerch_Full_Name + "<BR>");

                                                StringBuilder HTMLText = new StringBuilder();

                                                HTMLText.Append("<!DOCTYPE HTML PUBLIC '-//IETF//DTD HTML//EN'>");
												HTMLText.Append("<HTML>");
												HTMLText.Append("<TITLE align=center><FONT color=Green>" + vPrompts[14] + "</FONT></TITLE>"); 
												HTMLText.Append("<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>");
												//HTMLText.Append("<META content='MSHTML 5.00.2919.6307' name=GENERATOR>"
														
												HTMLText.Append("<BODY bgColor=#ffffff>");
												HTMLText.Append("<DIV align=center>");
												HTMLText.Append("<U><EM><FONT color=#ff0000>");
												HTMLText.Append("<STRONG> " + vPrompts[15] + " </STRONG>");
												//HTMLText.Append("<BR><META content='MSHTML 5.00.2919.6307' name=GENERATOR></FONT></EM></U></DIV>"

												HTMLText.Append("<DIV>");
												HTMLText.Append("<Table class=grid align=Center border=1 width=100% cellpadding=1 cellspacing=1>");

												HTMLText.Append("<TR bgcolor='DarkGray'>");
												HTMLText.Append("<TD align=Center>");
												HTMLText.Append("<STRONG><FONT color=white> " + vPrompts[16] + "</FONT></STRONG>");
												HTMLText.Append("</TD>");
												HTMLText.Append("</TR>");

												HTMLText.Append("<TR bgcolor='DarkGray'><TD class=fieldtitle align=left>");
												HTMLText.Append("<STRONG><FONT color=White>" + vPrompts[17] + "</FONT></STRONG>");
												HTMLText.Append("</TD></TR>");
														
														HTMLText.Append("<TR bgcolor='white'><TD class=fieldtitle align=left>");
                                                        HTMLText.Append("<STRONG><EM> " + vPrompts[3] + "</EM></STRONG>" + Job_No + " " + PTask_Addtl_Desc + ""); 
														HTMLText.Append("</TD></TR>");

														HTMLText.Append("<TR bgcolor='white'><TD class=fieldtitle align=left>");
                                                        HTMLText.Append("<STRONG><EM>" + vPrompts[4] + "</EM></STRONG>" + Wave_No + " ( " + vPrompts[18] + " " + PField_Start_Dt + " - " + vPrompts[19] + " " + PField_end_Dt + ")");
														HTMLText.Append("</TD></TR>");

														HTMLText.Append("<TR bgcolor='white'><TD class=fieldtitle align=left>");
                                                        HTMLText.Append("<STRONG><EM>" + vPrompts[5] + "</EM></STRONG>" + Task_No + " " + PTask_Desc + "");
														HTMLText.Append("</TD></TR>");
												//*********** Chain Information		
												HTMLText.Append("<TR bgcolor='DarkGray'><TD class=fieldtitle align=left>");
												HTMLText.Append("<STRONG><FONT color=White>" + vPrompts[20] + "</FONT></STRONG>"); 
												HTMLText.Append("</TD></TR>");		
													
														HTMLText.Append("<TR bgcolor='white'><TD class=fieldtitle align=left>");
                                                        HTMLText.Append("<STRONG><EM>" + vPrompts[6] + "</EM></STRONG>" + Chain_No + " " + PStore_Chain_Desc + "");
														HTMLText.Append("</TD></TR>");
														
												//************Store Information

												HTMLText.Append("<TR bgcolor='DarkGray'><TD class=fieldtitle align=left>");
												HTMLText.Append("<STRONG><FONT color=White>" + vPrompts[21] + "</FONT></STRONG>"); 
												HTMLText.Append("</TD></TR>");	

														HTMLText.Append("<TR bgcolor='white'><TD class=fieldtitle align=left>");
                                                        HTMLText.Append("<STRONG><EM>" + vPrompts[7] + "</EM></STRONG>" + Store_No + ""); 
														HTMLText.Append("</TD></TR>");	
														
														HTMLText.Append("<TR bgcolor='white'><TD class=fieldtitle align=left>");
                                                        HTMLText.Append("<STRONG><EM>" + vPrompts[22] + "</EM></STRONG>" + PStore_Store_Name + "");
														HTMLText.Append("</TD></TR>");
														
										  string[] ArrayAddress;
                                          int i;
                                          ArrayAddress = new string[3];
                                          ArrayAddress = AddressRule.Split(",".ToCharArray());
                                          
                                          for (i = 0; i < ArrayAddress.Length; i++)
                                          {
												 if (ArrayAddress[i].ToUpper() == ("Street").ToUpper())
                                                        {	
														HTMLText.Append("<TR bgcolor='white'><TD class=fieldtitle align=left>");
                                                        HTMLText.Append("<STRONG><EM>" + vPrompts[23] + "</EM></STRONG>" + PStore_Street_Addr + "");
														HTMLText.Append("</TD></TR>");
												        }
                                                if (ArrayAddress[i].ToUpper() == ("City").ToUpper())
                                                        {
														HTMLText.Append("<TR bgcolor='white'><TD class=fieldtitle align=left>");
                                                        HTMLText.Append("<STRONG><EM>" + vPrompts[24] + "</EM></STRONG>" + PStore_City + "");
														HTMLText.Append("</TD></TR>");
												        }
                                               if (ArrayAddress[i].ToUpper() == ("State").ToUpper())
                                                        {
														HTMLText.Append("<TR bgcolor='white'><TD class=fieldtitle align=left>");
                                                        HTMLText.Append("<STRONG><EM>" + vPrompts[25] + "</EM></STRONG>" + PStore_State + ""); 
														HTMLText.Append("</TD></TR>");
												        }
                                               if (ArrayAddress[i].ToUpper() == ("Zip").ToUpper())
                                                        {		
														HTMLText.Append("<TR bgcolor='white'><TD class=fieldtitle align=left>");
                                                        HTMLText.Append("<STRONG><EM>" + vPrompts[26] + "</EM></STRONG>" + PStore_Zip + "");
														HTMLText.Append("</TD></TR>");
                                                        }
                                          } 
												//*********** Merch Information
												HTMLText.Append("<TR bgcolor='DarkGray'><TD class=fieldtitle align=left>");
												HTMLText.Append("<STRONG><FONT color=White>" + vPrompts[27] + "</FONT></STRONG>" );
												HTMLText.Append("</TD></TR>");	

														HTMLText.Append("<TR bgcolor='white'><TD class=fieldtitle align=left>");
                                                        HTMLText.Append("<STRONG><EM>" + vPrompts[28] + "</EM></STRONG>" + Str_Merch_no + "");
														HTMLText.Append("</TD></TR>");
														
														HTMLText.Append("<TR bgcolor='white'><TD class=fieldtitle align=left>");
														HTMLText.Append("<STRONG><EM>" + vPrompts[29] + " </EM></STRONG>" + PMerch_Phone_No + ""); 
														HTMLText.Append("</TD></TR>");
														
														HTMLText.Append("<TR bgcolor='white'><TD class=fieldtitle align=left>");
														HTMLText.Append("<STRONG><EM>" + vPrompts[30] + "</EM></STRONG>" + PMerch_Email_Addr + ""); 
														HTMLText.Append("</TD></TR>");
															
												HTMLText.Append("<TR bgcolor='white'><TD align=center>");
												HTMLText.Append("<STRONG><FONT color=balck><EM>" + vPrompts[31] + "</EM></FONT></STRONG>" +  PMerch_Full_Name + "");
												HTMLText.Append("</TD></TR>");

												HTMLText.Append("<TR bgcolor='white'><TD align=center>");
												HTMLText.Append("<STRONG><FONT color=balck><EM>" + vPrompts[32] + "</EM></FONT></STRONG>");
												HTMLText.Append("</TD></TR>");

												HTMLText.Append("<TR bgcolor='white'><TD align=center>");
												
												//Response.Write "john=" & Cstr(ClientServPersonNo) & "<BR>"
												//Htmlmailtexttest ="LID=" + Trim(CStr(LangID)) + "&PID=" + Trim(CStr(Picture_Name)) + "&UID=" + Trim(Cstr(ClientServPersonNo)) + ""
												
												//Response.Write "Htmlmailtexttest=" & Htmlmailtexttest & "<BR>"
												
												//HTMLText.Append("<A href='http://mitest.sparinc.com/callforminput/sparEyesPic/sparEye_callform.asp?" + Htmlmailtexttest +"  '>" & v_Prompt(43) & "</A></font>     "
                                                //http://mi16.sparinc.com/SEMPA/spareyes_multiphotoapprove.aspx?LID=1&PID=9999200846132942037336_2009115151117&UID=14

												//HTMLText.Append("<A href='http://mitest.sparinc.com/callforminput/sparEyesPic/sparEye_callform.asp?LID=" + Trim(CStr(LangID)) + "&PID=" + Trim(CStr(Picture_Name)) + "&UID=" + Trim(Cstr(ClientServPersonNo)) + "'>" & v_Prompt(43) & "</A></font>"
												//HTMLText.Append("<A href=http://mi2.sparinc.com/sparEyesMulti/sparEye_callform.asp?LID=" + Trim(CStr(LangID)) + "&PID=" + Trim(CStr(Picture_Name)) + "&UID=" + Trim(CStr(ClientServPersonNo)) + ">" & v_Prompt(43) & "</A></font>"
                                                HTMLText.Append("<A href='http://mi10.sparinc.com/callforminput/sparEyesPic/sparEye_callform.asp?LID=" + Str_Lang_id + "&PID=" + Picture_Name + "&UID=" + PClientServ_PersonNo + "'>" + vPrompts[43] + "</A></font>");
                                               // HTMLText.Append("<A href='http://mi16.sparinc.com/SEMPA/spareyes_multiphotoapprove.aspx?LID=" + Str_Lang_id + "&PID=" + Picture_Name + "&UID=" + PClientServ_PersonNo + "'>" + vPrompts[43] + "</A></font>");
												HTMLText.Append("</TD></TR>");

												HTMLText.Append("</Table>");
												HTMLText.Append("</Body></Html>");
												//Htmlmailtext = Trim(Htmlmailtext)

                                                //Response.Write("HTMLText=" + HTMLText + "<BR>");
                                                EmailInfoText = HTMLText.ToString();
                                                //Response.Write("EmailInfoText=" + EmailInfoText + "<BR>");

                                                string EmailFrom, EmailTO, EmailCopy, EmailBC, EmailSubject, EmailBodyMessage, EmailPriority, EmailHost,EmailAddresses;
                                                bool EmailHTMLBody;

                                                if (string.IsNullOrEmpty(PEmail_String) == false)
                                                {
                                                    // EmailAddresses="jmasud@sparinc.com " + PEmail_String + "";
                                                    if (Lang_id != 7)
                                                    {

                                                        EmailFrom = "jmasud@sparinc.com";
                                                        EmailTO = PEmail_String;
                                                        //EmailTO = "jmasud@sparinc.com";
                                                        EmailCopy = "jmasud@sparinc.com";
                                                        EmailBC = "jmasud@sparinc.com";
                                                        EmailSubject = "Photo Email";
                                                        //EmailBodyMessage = "Good Job";
                                                        EmailPriority = "normal";
                                                        EmailHTMLBody = true;
                                                        EmailHost = "";

                                                        // AppMail.SendAppMail("jayachandran@muthutech.com", "nandhini@muthutech.com;jayachandran@muthutech.com", string.Empty, string.Empty, "Request for Rate Approval", HTML.ToString(), "normal", true, string.Empty);   
                                                        //AppMail.SendAppMail(EmailFrom, EmailTO, EmailCopy, EmailBC, EmailSubject, EmailBodyMessage, EmailPriority, EmailHTMLBody, EmailHost);

                                                        string sFromMailID = "";
                                                        string sBccMailID = "";

                                                        sFromMailID = ConfigurationManager.AppSettings["FromMailID"].ToString();
                                                        sBccMailID = ConfigurationManager.AppSettings["BccMailID"].ToString();

                                                        MailMessage mail = new MailMessage();
                                                        MailAddress from = new MailAddress(sFromMailID);
                                                        mail.From = from;
                                                        MailAddress to = new MailAddress(EmailTO);
                                                        mail.To.Add(to);
                                                        MailAddress bcc = new MailAddress(sBccMailID);
                                                        mail.Bcc.Add(bcc);
                                                        mail.Subject = "Photo Approval Notification";
                                                        mail.IsBodyHtml = true;
                                                        mail.Body = EmailInfoText;
                                                        SmtpClient SendEmailOut = new SmtpClient();
                                                        SendEmailOut.Send(mail);

                                                    }
                                                }
                                                 //SmtpClient client = new SmtpClient();
                                                 //client.Send(mail);
                                            //vPrompts[35]
                                            //vPrompts[30]
                                                 ErrorMessage.Text = vPrompts[35];
                                        }
                                    } //End of for loop


                    }
                    else
                    {
                        ErrorMessage.Text = "No file(s) were selected to upload!";
                        //DisplayConfirNo.InnerHtml = "No file(s) were selected to upload!";
                        //Response.Write("No file(s) were selected to upload!");
                    }
                    //Response.Write("test=" + StrOriginalFile);  
                    
                    //*************************** Delete files
                   int d, c;
                   string[] ArrayFiles = StrRotateFileSave.Split('|'); 
                   string[] ArrayFiles1 = StrOriginalFile.Split('|');
                   string ArrayOriginalFile, ArrayRotateFile, StrNewRotateFile;
                   c=ArrayFiles1.Length;

                   for (d = 0; d < c; d++)
                   {
                                           ArrayOriginalFile = ArrayFiles1[d];
                                           ArrayRotateFile = ArrayFiles[d];


                                           //StrNewRotateFile = "C:\\Photo\\Update\\" + ArrayRotateFile + ".jpg";
                                           StrNewRotateFile = "" + StrFileUpdatePath.Trim() + "" + ArrayRotateFile.Trim() + ".jpg";
                                          // Response.Write("ArrayOriginalFile1=" + ArrayOriginalFile + "<BR>");
                                           //Response.Write("ArrayOriginalFile2=" + @ArrayOriginalFile + "<BR>");

                                           if (File.Exists(@ArrayOriginalFile))
                                           {
                                                           

                                                           //******** Delete Files

                                                           //StrOriginalFile = Request.Form["StrOriginalFile"];
                                                          // StrRotateFileSave = Request.Form["StrRotateFileSave"];
                                                           //Delete the origional uploaded file
                                                           File.Delete(@ArrayOriginalFile);
                                                           //Delete file from rotate object
                                                           File.Delete(@StrNewRotateFile);

                                           }
                                           
                   }//End of for loop

    }
    //************* Function to insert the data
    private DataTable Get_PhotoInsert(String Job_No, String Wave_No, String Task_No, String Chain_No, String Store_No, String Str_Merch_no, Int32 Lang_id, String Picture_Name, String Visit_Date, String Comments, String PhotoFileName, String PhotoFilePath, Int32 confirmation_no,Int32 mWidth, Int32 mHeight)
    {
        Int32 iTempMerchNo = 0;
        Int32 iTempJob_No = 0;
        Int32 iTempWave_No = 0;
        Int32 iTempTask_No = 0;
        Int32 iTempChain_No = 0;
        Int32 iTempStore_No = 0;



        iTempMerchNo = AppUtils.ConvertToInteger32(Str_Merch_no, 0);
        iTempJob_No = AppUtils.ConvertToInteger32(Job_No, 0);
        iTempWave_No = AppUtils.ConvertToInteger32(Wave_No, 0);
        iTempTask_No = AppUtils.ConvertToInteger32(Task_No, 0);
        iTempChain_No = AppUtils.ConvertToInteger32(Chain_No, 0);
        iTempStore_No = AppUtils.ConvertToInteger32(Store_No, 0);
       //iTempconfirmation_no = AppUtils.ConvertToInteger32(confirmation_no, 0);
        //iTempPOutOfStock_no = AppUtils.ConvertToInteger32(POutOfStock_no, 0);

        return AppData.Get_CFPictureFileConfirmationinsert(iTempJob_No, iTempWave_No, iTempTask_No, iTempChain_No, iTempStore_No, iTempMerchNo, Lang_id, Picture_Name, PVisit_Date, Comments, PhotoFileName, PhotoFilePath, confirmation_no, mWidth, mHeight, WebAppClass.CurrentSQLDBConnection);
                                    
    }
   
    //************* Function to insert the data
    private DataTable Get_PhotoSentEmail(String Job_No, String Wave_No, String Task_No, String Chain_No, String Store_No, String Str_Merch_no)
    {
        Int32 iTempMerchNo = 0;
        Int32 iTempJob_No = 0;
        Int32 iTempWave_No = 0;
        Int32 iTempTask_No = 0;
        Int32 iTempChain_No = 0;
        Int32 iTempStore_No = 0;


        iTempMerchNo = AppUtils.ConvertToInteger32(Str_Merch_no, 0);
        iTempJob_No = AppUtils.ConvertToInteger32(Job_No, 0);
        iTempWave_No = AppUtils.ConvertToInteger32(Wave_No, 0);
        iTempTask_No = AppUtils.ConvertToInteger32(Task_No, 0);
        iTempChain_No = AppUtils.ConvertToInteger32(Chain_No, 0);
        iTempStore_No = AppUtils.ConvertToInteger32(Store_No, 0);
        //iTempconfirmation_no = AppUtils.ConvertToInteger32(confirmation_no, 0);
        //iTempPOutOfStock_no = AppUtils.ConvertToInteger32(POutOfStock_no, 0);

        return AppData.Get_CFPhotoSentEmail(iTempJob_No, iTempWave_No, iTempTask_No, iTempChain_No, iTempStore_No, iTempMerchNo,WebAppClass.CurrentSQLDBConnection);

    }
    #region SystemPromptandRule

    private void GetPromptTranslation()
    {
         vPrompts = new string[49];
         vPrompts[0]= "Internet Call Form";
         vPrompts[1]= "Date:";
         vPrompts[2]= "Picture Upload";
         vPrompts[3]= "Job No.";
         vPrompts[4]= "Wave No.";
         vPrompts[5]= "Task No.";
         vPrompts[6]= "Chain No.";
         vPrompts[7]= "Store No.";
         vPrompts[8]= "Comments";
         vPrompts[9]= "Picture:";
         vPrompts[10]= "Note: Picture has to be JPG file";
         vPrompts[11]= "2002 SPAR Group, Inc.";
         vPrompts[12]= "All Rights Reserved.";
         vPrompts[13]= "Upload A Picture";
         vPrompts[14]= "RESET/REMODEL EMAIL NOTIFICATION";
         vPrompts[15]= "EMAIL NOTIFICATION ON NEW PHOTO";
         vPrompts[16]= "SPAR GROUP - Internet Call Form Photo Upload";
         vPrompts[17]= "Job Information" ; 
         vPrompts[18]= "FST DT:";  
         vPrompts[19]= "FEnd DT:";
         vPrompts[20]= "Chain Information";
         vPrompts[21]= "Store Information";
         vPrompts[22]= "Store Name:";
         vPrompts[23]= "Street:";
         vPrompts[24]= "City:";
         vPrompts[25]= "State:";
         vPrompts[26]= "Zip:";
         vPrompts[27]= "Merch Information";
         vPrompts[28]= "Merch No:";									
         vPrompts[29]= "Phone No:";
         vPrompts[30]= "Email Address:";
         vPrompts[31]= "A picture has been uploaded by a following merchandiser:";
         vPrompts[32]= "To view and approve the photo, use the spar system tools.";
         vPrompts[33]= "Spar System Tools";
         vPrompts[34]= "ERROR: The picture you trying to upload doesn't exists. Please give the picture a correct path and upload it again.";
         vPrompts[35]= "Note: The Photo has been upload to the system for approval, please continue with either photo upload or the Call Form.";
         vPrompts[36]= "Note: The Photo has been upload to system for approval. Please go back because you don't have the access to the call form.";
         vPrompts[37]="The photo can not be uploaded at this time.";
         vPrompts[38]="Please logout and log back in again after few minutes."; 
         vPrompts[39]="If you are still having problems please call your DMM.";
         vPrompts[40]="Photo Upload";
         vPrompts[41]="Call Form";
         vPrompts[42]="Back";
         vPrompts[43]="Spar System Tools";
         vPrompts[44]= "HELP";
         vPrompts[45]="Confirmation Number(s)";
         vPrompts[46]= "Note: No Photo has been upload to the system for approval, please continue with either photo upload or the Call Form.";
         vPrompts[47]= "Note: No Photo has been upload to the system for approval. Please go back because you don't have the access to the call form.";
         vPrompts[48]= "Photo";



        ptAppTranslation.DoArrayPromptTranslation(vPrompts);


    }
    private DataTable GetSystemRules()
    {
        DataTable appDT = new DataTable();
        string[] VRule;
        VRule = new string[6];
        VRule[0] = "Name Format";
        VRule[1] = "New Date Format";
        VRule[2] = "Collect Mobile Email";
        VRule[3] = "SPAR Logo";
        VRule[4] = "SPAR Copyright";
        VRule[5] = "Address Format";
        appDT = AppSysRules.Get_RuleValue_ByDescAsDataTable(VRule, WebAppClass.LanguageId, WebAppClass.CurrentSQLDBConnection);
        return appDT;
    }

    #endregion
}
