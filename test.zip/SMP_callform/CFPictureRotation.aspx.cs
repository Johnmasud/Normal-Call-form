using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SPAR.Tools.Security;
using SPAR.Tools.MasterControls;
using SPAR.Tools.Utils;
using System.Reflection;
using System.IO;


public partial class CFPictureRotation : System.Web.UI.Page
{

    protected string FileCheck, Rotate, Path;
    protected int PicLen;

    protected void Page_Load(object sender, EventArgs e)
    {
        FileCheck = Request["FileCheck"];
        Rotate = Request["Rotate"];
        Path = Request["Path"];
        PicLen=0;
       //FileCheck ="C:\\Apps\\5002412009251999996333902009828139633390.jpg";
        System.IO.FileInfo pFileinfo = new System.IO.FileInfo(Path);

       ASPJPEGLib.IASPJpeg objJpeg;
      
       objJpeg = new ASPJPEGLib.ASPJpeg();
       objJpeg.RegKey = "04528-66434-31071";
       
     //objJpeg.Open("C:\\Apps\\johnTest.jpg");
       if (pFileinfo.Exists)
       {
           if (pFileinfo.Length > 0)
           {
               objJpeg.Open(@Path);
               if (Rotate == "1")
               {
                   objJpeg.FlipH();
               }
               if (Rotate == "2")
               {
                   objJpeg.FlipV();
               }

               if (Rotate == "3")
               {
                   objJpeg.RotateR();
               }
               if (Rotate == "4")
               {
                   objJpeg.RotateL();
               }
               //PicLen = Convert.(objJpeg.Binary);
               //;
               long filelength;
               filelength = 0;
               filelength = pFileinfo.Length;

               if ( filelength > 0 && filelength <= 307200 )
               {
                   objJpeg.Quality = 90;
               }

               if ( filelength > 307200 && filelength <= 409600 )
               {
                   objJpeg.Quality = 80;
               }
               
               if ( filelength > 409600 && filelength <= 512000 )
               {
                   objJpeg.Quality = 70;
               }
               
               if ( filelength > 512000 && filelength <= 614400 )
               {
                   objJpeg.Quality = 60;
               }
               
               if ( filelength > 614400 && filelength <= 1024000 )
               {
                   objJpeg.Quality = 50;
               }

               if ( filelength > 1024000  )
               {
                   objJpeg.Quality = 40;
               }
                   

               //if (pFileinfo.Length > 200000)
               //{
               //    objJpeg.Quality = 20;

               //    if (objJpeg.OriginalWidth > 600)
               //    {
               //        //objJpeg.Width = 1000;
               //        objJpeg.Width = 600;
               //        objJpeg.Height = objJpeg.OriginalHeight * objJpeg.Width / objJpeg.OriginalWidth;
               //    }

               //}

               objJpeg.Save(FileCheck);
               objJpeg.SendBinary(Missing.Value);
           }
       }
       objJpeg.Close();
    }
    static bool IsJpegHeader(string filename)
    {
        using (BinaryReader br = new BinaryReader(File.Open(filename, FileMode.Open)))
        {
            UInt16 soi = br.ReadUInt16();  // Start of Image (SOI) marker (FFD8)     
            UInt16 jfif = br.ReadUInt16(); // JFIF marker (FFE0)       
            return soi == 0xd8ff && jfif == 0xe0ff;
        }
    }

}
