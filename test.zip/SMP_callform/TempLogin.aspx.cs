﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class TempLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //HttpCookie appcookies = null;
        //appcookies = HttpContext.Current.Request.Cookies["languageid"];        
       // Response.Cookies.Set(new HttpCookie("LANGUAGEID", "09"));
        //Response.Cookies.Set(new HttpCookie("MULTILANCNT", "1"));
       // Response.Cookies.Set(new HttpCookie("SPARTOOLSNEW", "241699925148hmufti"));

    }
    
}
